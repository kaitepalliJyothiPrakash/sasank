#!/bin/bash
echo "Starting FinVista Capital Assistant..."

# Auto-index PDFs on startup if keys are available
python3 /app/app/preload.py

# Start Streamlit
exec streamlit run /app/app/streamlit_app.py \
    --server.port=8501 \
    --server.address=0.0.0.0 \
    --server.maxUploadSize=200
