# 📊 FinVista Capital — Financial Intelligence Assistant

An enterprise RAG (Retrieval-Augmented Generation) application that enables intelligent Q&A over financial documents.

**Live URL:** `http://<your-loadbalancer>.eu-north-1.elb.amazonaws.com`  
**GitHub:** [Sasank2126/finvista-assistant](https://github.com/Sasank2126/finvista-assistant)

---

## Architecture

```
PDF Upload → PyMuPDF → Chunking → Gemini Embeddings → ChromaDB
User Query → Gemini Embedding → Semantic Search → Top-5 Chunks
                                                         ↓
                                          Groq LLM (llama-3.3-70b)
                                                         ↓
                                          Answer + Citations
```

| Component | Technology |
|---|---|
| LLM (chat responses) | Groq `llama-3.3-70b-versatile` — free, no credit card |
| Embeddings | Gemini `gemini-embedding-001` — free tier |
| Vector Store | ChromaDB 0.4.24 |
| PDF Parser | PyMuPDF (fitz) |
| Chunking | LangChain RecursiveCharacterTextSplitter |
| UI | Streamlit 1.35.0 |
| Container | Docker (python:3.11-slim, non-root) |
| Orchestration | Kubernetes (AWS EKS) |
| CI/CD | GitHub Actions |

---

## Project Structure

```
finvista-assistant/
├── app/
│   ├── rag_engine.py          # Core RAG: parse, chunk, embed, search, respond
│   ├── streamlit_app.py       # Web UI: API key inputs, upload, chat, history
│   ├── preload.py             # Auto-index PDFs on pod startup
│   ├── startup.sh             # Container entrypoint
│   ├── .streamlit/
│   │   └── config.toml        # maxUploadSize=200, maxMessageSize=200
│   └── data/
│       ├── 01_FinVista_Annual_Report_2024.pdf
│       ├── 02_FinVista_Investment_Policy_2024.pdf
│       ├── 03_FinVista_Compliance_Manual_2024.pdf
│       ├── 04_FinVista_Market_Intelligence_Q4_2024.pdf
│       └── 05_FinVista_Risk_Assessment_Framework.pdf
├── k8s/
│   ├── 01-namespace-configmap.yaml
│   ├── 02-secret.yaml         # GEMINI_API_KEY + GROQ_API_KEY (base64)
│   ├── 03-pvc.yaml
│   ├── 04-deployment.yaml     # 2 replicas, emptyDir, both API keys
│   ├── 05-service-ingress.yaml # LoadBalancer, 600s timeout
│   └── 06-hpa.yaml            # 2-10 replicas, CPU/memory autoscaling
├── tests/
│   └── test_rag_engine.py     # 12 unit tests, all services mocked
├── .github/
│   └── workflows/
│       └── ci-cd.yml          # pytest → ECR push → EKS deploy
├── Dockerfile
├── requirements.txt
├── .env.example
├── .gitignore
└── .dockerignore
```

---

## Quick Start — Local on EC2

```bash
cd ~/finvista
source venv/bin/activate

# Index all 5 PDFs
python3 - << 'EOF'
import sys, os
sys.path.insert(0, 'app')
for line in open('.env'):
    if '=' in line and not line.startswith('#'):
        k, v = line.strip().split('=', 1); os.environ[k] = v
from rag_engine import index_document, get_collection_stats
for i, n in [(1,'Annual_Report_2024'),(2,'Investment_Policy_2024'),
             (3,'Compliance_Manual_2024'),(4,'Market_Intelligence_Q4_2024'),
             (5,'Risk_Assessment_Framework')]:
    try: print(f"OK  0{i}_FinVista_{n}.pdf -- {index_document(f'app/data/0{i}_FinVista_{n}.pdf')} chunks")
    except Exception as e: print(f"ERR {e}")
stats = get_collection_stats()
print(f"Total: {stats['document_count']} docs, {stats['total_chunks']} chunks")
EOF

# Run app
streamlit run app/streamlit_app.py --server.address=0.0.0.0 --server.port=8501
# Open: http://YOUR_EC2_IP:8501
```

---

## Deploy to Kubernetes

```bash
# 1. Encode API keys
GEMINI_B64=$(grep GEMINI_API_KEY .env | cut -d'=' -f2 | tr -d '\n' | base64)
GROQ_B64=$(grep GROQ_API_KEY .env | cut -d'=' -f2 | tr -d '\n' | base64)

# Update secret file with encoded keys
# (edit k8s/02-secret.yaml with the encoded values)

# 2. Build and push Docker image
ECR_URI="106062677957.dkr.ecr.eu-north-1.amazonaws.com/finvista-assistant"
aws ecr get-login-password --region eu-north-1 | docker login --username AWS --password-stdin $ECR_URI
docker build --no-cache -t finvista-assistant:latest .
docker tag finvista-assistant:latest $ECR_URI:latest
docker push $ECR_URI:latest

# 3. Apply manifests
kubectl apply -f k8s/
kubectl get pods -n finvista -w

# 4. Get URL
kubectl get service finvista-service -n finvista
```

---

## CI/CD Pipeline

Every push to `main` triggers 3 jobs automatically:

1. **Run Tests** (~40s) — pytest with all services mocked
2. **Build & Push to ECR** (~1m 47s) — Docker build + push to AWS ECR
3. **Deploy to EKS** (~31s) — kubectl apply to finvista-cluster

**Required GitHub Secrets:**

| Secret | Description |
|---|---|
| `GEMINI_API_KEY` | Google AI Studio key (AIzaSy...) |
| `GROQ_API_KEY` | Groq API key (gsk_...) |
| `AWS_ACCESS_KEY_ID` | AWS IAM access key (AKIA...) |
| `AWS_SECRET_ACCESS_KEY` | AWS IAM secret key |

---

## API Keys

| Key | Where to get | Cost |
|---|---|---|
| Gemini | [aistudio.google.com](https://aistudio.google.com) | Free |
| Groq | [console.groq.com/keys](https://console.groq.com/keys) | Free, no credit card |

---

## Environment Variables

Copy `.env.example` to `.env` and fill in your keys:

```bash
cp .env.example .env
nano .env
```

```env
GEMINI_API_KEY=AIzaSy-your-actual-key-here
GROQ_API_KEY=gsk_your-actual-key-here
CHROMA_DB_PATH=./chroma_db
```

---

## Run Tests

```bash
source venv/bin/activate
pytest tests/ -v
# 12 tests — all pass with mocked services, no API calls made
```

---

## Infrastructure

| Resource | Value |
|---|---|
| AWS Region | eu-north-1 (Stockholm) |
| EKS Cluster | finvista-cluster |
| ECR Repository | 106062677957.dkr.ecr.eu-north-1.amazonaws.com/finvista-assistant |
| EC2 (terminal) | Ubuntu 25.04, t3.medium |
| K8s Nodes | 2x t3.medium |
| Replicas | 2 (auto-scales to 10) |

**Estimated cost:** ~$5.50/day running continuously.  
Delete cluster when not in use: `eksctl delete cluster --name finvista-cluster --region eu-north-1`

---

## Restore After Cluster Deletion

```bash
# 1. Recreate cluster (15-20 min)
eksctl create cluster --name finvista-cluster --region eu-north-1 \
  --nodegroup-name finvista-nodes --node-type t3.medium --nodes 2 --managed

# 2. Update kubeconfig
aws eks update-kubeconfig --name finvista-cluster --region eu-north-1

# 3. Trigger CI/CD (easiest)
echo " " >> README.md && git add README.md && git commit -m "redeploy" && git push

# 4. Get new URL
kubectl get service finvista-service -n finvista
```

---

*Built with Groq + Gemini + ChromaDB + Streamlit + Docker + Kubernetes*
